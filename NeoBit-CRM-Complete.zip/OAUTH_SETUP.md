# OAuth Setup Instructions

## 🔴 Current Error
Both Google and GitHub OAuth are showing `redirect_uri_mismatch` errors because the redirect URIs are not registered in the OAuth app settings.

---

## ✅ Solution 1: Add Redirect URIs to OAuth Apps (Quick Fix)

### Google OAuth Setup

1. **Go to Google Cloud Console**
   - Visit: https://console.cloud.google.com/apis/credentials
   - Select your project (or create one)

2. **Find Your OAuth 2.0 Client**
   - Look for Client ID: `912910293606-g20s0rs4rhs3nftqkvi9s7isj6n07m4j.apps.googleusercontent.com`
   - Click **Edit** (pencil icon)

3. **Add Authorized JavaScript origins:**
   ```
   http://localhost:3000
   http://localhost:8080
   ```

4. **Add Authorized redirect URIs:**
   ```
   http://localhost:3000
   http://localhost:3000/
   http://localhost:8080/api/auth/google/callback
   ```

5. **Click Save**

---

### GitHub OAuth Setup

1. **Go to GitHub Developer Settings**
   - Visit: https://github.com/settings/developers
   - Click **OAuth Apps** → **New OAuth App** (or edit existing)

2. **Find Your OAuth App**
   - Client ID: `Ov23liOFyLPSQHt1LZtN`
   - Click **Edit**

3. **Update Application settings:**
   - **Application name**: NeoBit CRM
   - **Homepage URL**: `http://localhost:3000`
   - **Authorization callback URL**: `http://localhost:3000`
   - **Authorization callback URL (alternative)**: `http://localhost:8080/api/auth/github/callback`

4. **Click Update application**

---

## ✅ Solution 2: Use Backend Redirect (Recommended - More Secure)

For production, it's better to use the backend as the redirect URI. Update the frontend code to use:

```javascript
// Google OAuth - Use backend redirect
const redirectUri = encodeURIComponent('http://localhost:8080/api/auth/google/callback');

// GitHub OAuth - Use backend redirect  
const redirectUri = encodeURIComponent('http://localhost:8080/api/auth/github/callback');
```

Then add these redirect URIs to your OAuth apps:
- **Google**: `http://localhost:8080/api/auth/google/callback`
- **GitHub**: `http://localhost:8080/api/auth/github/callback`

---

## 🧪 Test After Configuration

1. **Clear browser cache/localStorage:**
   ```javascript
   localStorage.clear();
   ```

2. **Try Google OAuth:**
   - Click "Continue with Google"
   - Should redirect to Google login
   - After login, should redirect back to app

3. **Try GitHub OAuth:**
   - Click "Continue with GitHub"
   - Should redirect to GitHub login
   - After login, should redirect back to app

---

## 📝 Quick Reference

### Google Cloud Console
- **URL**: https://console.cloud.google.com/apis/credentials
- **Client ID**: `912910293606-g20s0rs4rhs3nftqkvi9s7isj6n07m4j.apps.googleusercontent.com`
- **Client Secret**: `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`

### GitHub OAuth App
- **URL**: https://github.com/settings/developers
- **Client ID**: `Ov23liOFyLPSQHt1LZtN`
- **Client Secret**: `3f5d2da5b2e277c67c8a45258cbfdfc5db7a49e0`

---

## ⚠️ Important Notes

1. **For Production**: Use HTTPS URLs and proper domain names
2. **Security**: Never commit OAuth secrets to version control
3. **Testing**: Use `localhost` for development, real domains for production

